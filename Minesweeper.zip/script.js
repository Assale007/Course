const board = document.getElementById('board');
const timerDisplay = document.getElementById('timer');
const highScoreDisplay = document.getElementById('high-score');
const startButton = document.getElementById('start-button');
const ROWS = 10;
const COLS = 10;
const MINES = 10;
let revealedCount = 0;
let isGameActive = false;
let timerInterval;
let seconds = 0;
let highScore = localStorage.getItem('minesweeperHighScore') || 'N/A';

// Update high score display
highScoreDisplay.textContent = highScore;

// Create the grid
const grid = [];
for (let row = 0; row < ROWS; row++) {
  grid[row] = [];
  for (let col = 0; col < COLS; col++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.dataset.row = row;
    cell.dataset.col = col;
    cell.addEventListener('click', handleCellClick);
    board.appendChild(cell);
    grid[row][col] = {
      element: cell,
      isMine: false,
      isRevealed: false,
      neighborCount: 0
    };
  }
}

// Generate random mine locations
let mineCount = 0;
while (mineCount < MINES) {
  const row = Math.floor(Math.random() * ROWS);
  const col = Math.floor(Math.random() * COLS);
  if (!grid[row][col].isMine) {
    grid[row][col].isMine = true;
    mineCount++;
  }
}

// Update neighbor counts
for (let row = 0; row < ROWS; row++) {
  for (let col = 0; col < COLS; col++) {
    if (!grid[row][col].isMine) {
      let count = 0;
      for (let i = -1; i <= 1; i++) {
        for (let j = -1; j <= 1; j++) {
          const newRow = row + i;
          const newCol = col + j;
          if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS && grid[newRow][newCol].isMine) {
            count++;
          }
        }
      }
      grid[row][col].neighborCount = count;
    }
  }
}

// Handle cell click
function handleCellClick(event) {
  if (!isGameActive) {
    return;
  }

  const row = parseInt(event.target.dataset.row);
  const col = parseInt(event.target.dataset.col);
  const cell = grid[row][col];

  if (cell.isRevealed || cell.element.classList.contains('flag')) {
    return;
  }

  if (cell.isMine) {
    revealAllMines();
    endGame(false);
    return;
  }

  revealCell(cell);
  checkWinCondition();
}

// Reveal a cell
function revealCell(cell) {
  cell.isRevealed = true;
  cell.element.classList.add('revealed');
  revealedCount++;

  if (cell.neighborCount > 0) {
    cell.element.textContent = cell.neighborCount;
  } else {
    // Auto-reveal neighboring cells if count is 0
    const row = parseInt(cell.element.dataset.row);
    const col = parseInt(cell.element.dataset.col);
    for (let i = -1; i <= 1; i++) {
      for (let j = -1; j <= 1; j++) {
        const newRow = row + i;
        const newCol = col + j;
        if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS) {
          const neighbor = grid[newRow][newCol];
          if (!neighbor.isMine && !neighbor.isRevealed) {
            revealCell(neighbor);
          }
        }
      }
    }
  }
}

// Reveal all mines
function revealAllMines() {
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cell = grid[row][col];
      if (cell.isMine) {
        cell.element.classList.add('mine');
      }
    }
  }
}

// Check win condition
function checkWinCondition() {
  const totalCells = ROWS * COLS;
  const safeCells = totalCells - MINES;
  if (revealedCount === safeCells) {
    revealAllMines();
    endGame(true);
  }
}

// Start the game
function startGame() {
  isGameActive = true;
  timerInterval = setInterval(updateTimer, 1000);
  startButton.disabled = true;
}

// End the game
function endGame(isWin) {
  clearInterval(timerInterval);
  isGameActive = false;
  startButton.disabled = false;

  if (isWin) {
    const elapsedTime = seconds;
    if (elapsedTime < highScore || highScore === 'N/A') {
      highScore = elapsedTime;
      localStorage.setItem('minesweeperHighScore', highScore);
    }
    highScoreDisplay.textContent = highScore;
    alert('Congratulations! You win!');
  } else {
    alert('Game over!');
  }

  setTimeout(restartGame, 1000);
}

// Restart the game
function restartGame() {
  revealedCount = 0;
  seconds = 0;
  timerDisplay.textContent = formatTime(seconds);

  // Reset cell states and classes
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cell = grid[row][col];
      cell.isRevealed = false;
      cell.element.classList.remove('revealed', 'mine');
      cell.element.textContent = '';
    }
  }
}

// Update the timer display
function updateTimer() {
  seconds++;
  timerDisplay.textContent = formatTime(seconds);
}

// Format time in MM:SS format
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${padZero(minutes)}:${padZero(remainingSeconds)}`;
}

// Pad zero to single-digit numbers
function padZero(num) {
  return num < 10 ? `0${num}` : num;
}

// Event listener for start button
startButton.addEventListener('click', startGame);